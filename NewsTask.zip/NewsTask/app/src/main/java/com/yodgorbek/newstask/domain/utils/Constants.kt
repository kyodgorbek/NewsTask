package com.yodgorbek.newstask.domain.utils

object Constants {
  const val BASE_URL = "https://newsapi.org/"
  const val BBC_URL = "v2/top-headlines?sources=bbc-news&apiKey=da331087e3f3462bb534b3b0917cbee9"

}