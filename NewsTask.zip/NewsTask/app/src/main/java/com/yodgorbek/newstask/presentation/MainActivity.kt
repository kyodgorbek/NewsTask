package com.yodgorbek.newstask.presentation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.yodgorbek.newstask.R


class MainActivity : AppCompatActivity(R.layout.activity_main){
 override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
  }
}